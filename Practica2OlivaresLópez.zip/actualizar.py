import time
import rrdtool
from getSNMP import consultaSNMP
while 1:
    pUrecibidos = int(consultaSNMP('comunidadSNMP','192.168.0.100','1.3.6.1.2.1.2.2.1.11.2')) #interfaz 3
    pRecibidosIP = int(consultaSNMP('comunidadSNMP','192.168.0.100','1.3.6.1.2.1.4.3.0')) #incluidos erroneos
    msgICMPechoEnv = int(consultaSNMP('comunidadSNMP','192.168.0.100','1.3.6.1.2.1.5.21.0')) #Con ping
    segRecibICMPErr = int(consultaSNMP('comunidadSNMP','192.168.0.100','1.3.6.1.2.1.5.1.0')) #Recibido
    dataEnviadosUDP = int(consultaSNMP('comunidadSNMP','192.168.0.100','1.3.6.1.2.1.7.1.0')) #datagramas Enviados
    valor = 'N:' + str(pUrecibidos) + ':' + str(pRecibidosIP) + ':' + str(msgICMPechoEnv) + ':' + str(segRecibICMPErr) + ':' + str(dataEnviadosUDP)
    rrdtool.update('/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd', valor)
    rrdtool.dump('/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd', '/home/gerur/Documentos/ASR/Practicas/2con1agente/trafico.xml')
    print(valor)
    time.sleep(1)

if ret:
    print (rrdtool.error())
    time.sleep(10)