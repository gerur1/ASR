import rrdtool
ret = rrdtool.create('/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd',
                     "--start",'N',
                     "--step",'60',
                     "DS:paUnicastRecibidos:COUNTER:300:U:U",
                     "DS:pqIpRecibidos:COUNTER:300:U:U",
                     "DS:msgICMPechoEnv:COUNTER:300:U:U",
                     "DS:segICMPrecibidos:COUNTER:300:U:U",
                     "DS:datagramasUDPent:COUNTER:300:U:U",
                     "RRA:AVERAGE:0.5:1:720")

if ret:
    print (rrdtool.error())