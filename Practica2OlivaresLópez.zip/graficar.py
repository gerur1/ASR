import rrdtool
import time
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from getSNMP import consultaSNMP



#tiempo_actual = time.time()
diaI =int(input("Ingresa el día del inicio: "))
horaI = int(input("Ingresa la hora del inicio: "))
minutosI = int(input("Ingresa los minutos del inicio: "))-1#Porque para me da un dato adelante
segundosI = int(input("Ingresa los segundos de inicio: "))
print("-------------------------------------------------------------------------")
t1 = (2022, 11, diaI, horaI, minutosI, segundosI, 0, 0, 0)#Se almacenan como struct
inferior = int(time.mktime(t1))#mktime sirve para convertir a segundos desde el 01/01/1970

diaT =int(input("Ingresa el día de termino: "))
horaT = int(input("Ingresa la hora de termino: "))
minutosT = int(input("Ingresa los minutos  termino: "))-1
segundosT = int(input("Ingresa los segundos de termino: "))

t2 = (2022, 11, diaT, horaT, minutosT, segundosT, 0, 0, 0)
superior = int(time.mktime(t2))
####################Información para el reporte###########################################
info = str(rrdtool.info("/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd"))
infoFormato = info.replace("'", "").split(',')#no se porque no me la da con formato :(
#print(infoFormato)
version = infoFormato[1]
creacion = rrdtool.first("/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd")
ultima = rrdtool.last("/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd")
tamanio= infoFormato[4]
#print(version, time.ctime(creacion), time.ctime(ultima),tamanio)
datos = rrdtool.fetch("/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd",
                         "AVERAGE", "-s,"+str(inferior), '-e,'+str(superior))[2]
#print(datos[0][0])
ret = rrdtool.graph("/home/gerur/Documentos/ASR/Practicas/2con1agente/uniCrecibido.png",
                     "--start",str(inferior),
                     "--end",str(superior),
                     "--vertical-label=paquetes",
                     "--title=Paquetes Unicast recibidos \n Usando SNMP y RRDtools",
                     "DEF:pqUNICASTin=/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd:paUnicastRecibidos:AVERAGE",
                     "CDEF:escalaIn=pqUNICASTin,5,*",
                     "LINE1:escalaIn#3352ff:Paquetes Unicast Recibidos")


ret1 = rrdtool.graph("/home/gerur/Documentos/ASR/Practicas/2con1agente/paqIPrecibidos.png",
                     "--start",str(inferior),
                     "--end",str(superior),
                     "--vertical-label=paquetes",
                     "--title=Paquetes IP recibidos (incluye errores) \n Usando SNMP y RRDtools",
                     "DEF:paqIPrecibidos=/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd:pqIpRecibidos:AVERAGE",
                     "CDEF:escalaIn=paqIPrecibidos,5,*",
                     "LINE1:escalaIn#77ff33:Paquetes IP Recibidos")

ret2 = rrdtool.graph("/home/gerur/Documentos/ASR/Practicas/2con1agente/icmpEcho.png",
                     "--start",str(inferior),
                     "--end",str(superior),
                     "--vertical-label=paquetes",
                     "--title=Paquetes ICMP echo enviados \n Usando SNMP y RRDtools",
                     "DEF:icmpEcho=/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd:msgICMPechoEnv:AVERAGE",
                     "CDEF:escalaIn=icmpEcho,5,*",
                     "LINE1:escalaIn#ea19e7:Paquetes icmp echo Recibidos")
ret3 = rrdtool.graph("/home/gerur/Documentos/ASR/Practicas/2con1agente/icmpRecibidos.png",
                     "--start",str(inferior),
                     "--end",str(superior),
                     "--vertical-label=paquetes",
                     "--title=Paquetes ICMP recibidos \n Usando SNMP y RRDtools",
                     "DEF:icmpRecibidos=/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd:segICMPrecibidos:AVERAGE",
                     "CDEF:escalaIn=icmpRecibidos,5,*",
                     "LINE1:escalaIn#FF0000:Paquetes icmp Recibidos")
ret3 = rrdtool.graph("/home/gerur/Documentos/ASR/Practicas/2con1agente/datagramUDP.png",
                     "--start",str(inferior),
                     "--end",str(superior),
                     "--vertical-label=paquetes",
                     "--title=Datagramas UDP enviados \n Usando SNMP y RRDtools",
                     "DEF:datagramUDP=/home/gerur/Documentos/ASR/Practicas/2con1agente/definicion.rrd:datagramasUDPent:AVERAGE",
                     "CDEF:escalaIn=datagramUDP,5,*",
                     "LINE1:escalaIn#00fff0:Datagramas UDP enviados")
#Comenzamos a escribir en el archivo
pUnicast = 0.0
pIPent = 0.0
pICMPechoSal = 0.0
pICMPent = 0.0
pDataEnt = 0.0

for i in datos:
    pUnicast = pUnicast+float(i[0])
    pIPent = pIPent + float(i[1])
    pICMPechoSal = pICMPechoSal + float(i[2])
    pICMPent = pICMPent + float(i[3])
    pDataEnt = pDataEnt + float(i[4])
    #print(i)

#print(pUnicast, pIPent, pICMPechoSal, pICMPent, pDataEnt)

w, h = A4
c = canvas.Canvas("reporte.pdf", pagesize=A4)
text = c.beginText(50, h - 50)
text.setFont("Times-Roman", 12)
text.textLine("Administración de servicios en red")
text.textLine("Practica 2")
text.textLine("Alumno:Olivares López Gerson Uriel Grupo:4CM16")
text.textLine("************************************************")
text.textLine(version)
text.textLine('Creación de la BD: '+time.ctime(creacion))
text.textLine('Último dato: '+time.ctime(ultima))
text.textLine(tamanio)
text.textLine('fecha del reporte: '+time.ctime(time.time()))
text.textLine('Host: ' + consultaSNMP('comunidadSNMP','192.168.0.100', '1.3.6.1.2.1.1.5.0'))
text.textLine('Contacto: ' + consultaSNMP('comunidadSNMP','192.168.0.100', '1.3.6.1.2.1.1.4.0'))
text.textLine("************************************************")
text.textLine("-----------------Información de paquetes-----------------------------")
text.textLine('Paquetes Unicast recibidos por la interfaz 3: ' + str(pUnicast))
text.textLine('Paquetes IP recibidos por la interfaz: ' + str(pIPent))
text.textLine('Mensajes ICMP echo enviados ' + str(pICMPechoSal))
text.textLine('Mensajes ICMP recibidos ' + str(pICMPent))
text.textLine('Datagramas enviados ' + str(pDataEnt))
text.textLine("-----------------Graficas-----------------------------")
c.drawText(text)
c.drawImage('uniCrecibido.png', 50, 325)
c.drawImage('paqIPrecibidos.png', 50, 100)
c.showPage()
c.drawImage('icmpEcho.png', 50, 600)
c.drawImage('icmpRecibidos.png', 50, 350)
c.drawImage('datagramUDP.png', 50, 100)
c.save()